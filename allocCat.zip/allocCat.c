//--------------------------------------------------------------------------------
//  Quiz 7
//
// Your name goes here
//--------------------------------------------------------------------------------

#include <stdio.h>
#include <stdlib.h>
#include <string.h> 
#include <conio.h>
#define ARRAY_SIZE 3
#pragma warning(disable: 4996)

struct words
{
	int numberOfWords;
	char theWords[ARRAY_SIZE][FILENAME_MAX];
};
typedef struct words Words;

// allocCat prototype (declaration) goes here:


int main(void)
{
	
	Words myWords = { ARRAY_SIZE, { "stuff", " and", " nonsense" } };
	char* fullString = NULL;

	fullString = allocCat(&myWords); //calls the function you write below
	if (fullString == NULL)
	{		 // get out if memory not allocated
		fprintf(stderr, "Could not allocate memory\n");
		return EXIT_FAILURE;
	}
	puts(fullString); 	// prints out the new string
	free(fullString);	// releases memory
	getchar();
	return EXIT_SUCCESS;
}


// allocCat definition goes here: